package com.example.orangetask.common.data.remote.entity

data class Source(
    val id: Any,
    val name: String
)