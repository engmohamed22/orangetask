package com.example.orangetask.common

class Constants {

    companion object {
        val API_KEY = "e74b374e7284413eaac75d17714891c9"
        val BASE_URL = "https://newsapi.org/"
    }
}