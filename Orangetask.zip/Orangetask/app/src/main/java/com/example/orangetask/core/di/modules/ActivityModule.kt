package com.example.orangetask.core.di.modules

import android.app.Activity
import android.content.Context
import com.example.orangetask.core.di.context.ActivityContext
import com.example.orangetask.core.di.scopes.PerActivity
import dagger.Module
import dagger.Provides

@Module
class ActivityModule(private val activity : Activity) {

    @PerActivity
    @Provides
    @ActivityContext
    fun provideContext(): Context = activity

}