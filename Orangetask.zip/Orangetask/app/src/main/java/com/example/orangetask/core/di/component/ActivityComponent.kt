package com.example.orangetask.core.di.component

import com.example.orangetask.core.di.scopes.PerActivity
import com.example.orangetask.core.di.modules.ActivityModule
import dagger.Component


@PerActivity
@Component(modules = arrayOf(ActivityModule::class))
interface ActivityComponent