package com.example.orangetask.common.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.orangetask.common.data.local.ArticleEntity
import com.example.orangetask.common.data.remote.entity.Article

@Dao
interface ArticleDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(article: ArticleEntity) : Long

    @Query("SELECT * FROM articles")
    fun getAllArticles() : LiveData<List<ArticleEntity>>

    @Query("DELETE FROM articles WHERE url = :url")
    suspend fun deleteArticle(url : String)

}