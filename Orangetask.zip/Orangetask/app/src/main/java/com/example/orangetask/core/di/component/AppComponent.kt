package com.example.orangetask.core.di.component

import android.app.Application
import com.example.orangetask.core.di.modules.NetworkModule
import com.example.orangetask.core.di.modules.ViewModelModule
import com.example.orangetask.core.di.modules.RepositoryModule
import com.example.orangetask.core.di.modules.RoomDBModule
import com.example.orangetask.ui.ArticleFragment
import com.example.orangetask.ui.BreakingNewsFragment
import com.example.orangetask.ui.SavedNewsFragment
import com.example.orangetask.ui.SearchNewsFragment
import dagger.BindsInstance
import dagger.Component
import javax.inject.Singleton

@Singleton
@Component(modules = [
    NetworkModule::class,
    ViewModelModule::class,
    RoomDBModule::class,
    RepositoryModule::class
])
interface AppComponent {

    @Component.Builder
    interface Builder {
        @BindsInstance
        fun application(application: Application): Builder

        fun build(): AppComponent
    }

    fun inject(breakingNewsFragment : BreakingNewsFragment)

    fun inject(articleFragment: ArticleFragment)

    fun inject(savedNewsFragment: SavedNewsFragment)

    fun inject(searchNewsFragment: SearchNewsFragment)

}