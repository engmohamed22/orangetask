package com.example.orangetask.core.di.modules


import com.example.orangetask.common.presentation.NewsRepository
import com.example.orangetask.common.data.local.ArticleDatabase
import com.example.orangetask.core.network.NewsAPI
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
class RepositoryModule {

    @Provides
    @Singleton
    fun provideRepository(db : ArticleDatabase,
                          api : NewsAPI
    ) : NewsRepository{
        return NewsRepository(db, api)
    }

}